# Mamaearth Returns & Growth Intelligence Pipeline

A reproducible, three-layer capstone pipeline for SQL reporting, pandas cleaning/EDA, visual analysis, and a GenAI-assisted Situation–Complication–Resolution (SCR) narrative. The raw CSVs under `data/` are the source of truth and must not be manually edited.

## Repository structure

- `data/`: source customers, products, and orders CSVs.
- `sql/schema.sql`: creates the relational tables and keys.
- `sql/seed_data.sql`: generated inserts for the exact CSV seed data.
- `sql/reports.sql`: required SQL reports with expected results documented in comments.
- `analysis/clean_and_eda.py`: independently loads raw CSVs, standardizes and cleans orders, prints the acceptance checks, computes EDA, and writes `narrator/findings.json` plus `analysis/eda_results.json`.
- `analysis/visualize.py`: reads computed EDA output and regenerates the two PNG charts.
- `visualizations/`: generated charts.
- `narrator/findings.json`: analysis-generated verified metrics consumed by the narrator.
- `narrator/generate_narrative.py`: Gemini API narrative generator with deterministic offline fallback and numeric checker.
- `narrator/sample_output.txt`: saved, checked SCR narrative for grading without a live API call.

## Setup

Use Python 3.10 or newer. From the repository root:

```bash
python -m venv .venv
# Windows PowerShell: .venv\Scripts\Activate.ps1
# macOS/Linux: source .venv/bin/activate
python -m pip install -r requirements.txt
```

SQLite is included with standard Python installations. You can use the `sqlite3` command-line tool or a SQLite GUI.

## Run the pipeline in order

### 1. SQL relational layer and reports

From the repository root, create/reset the tables, load seed data, and run the reports:

```bash
python sql/run_sql.py
```

This portable runner uses Python's built-in SQLite module, creates `mamaearth.db`, loads the schema and seed data, and prints the report results. If you have the SQLite command-line tool installed, you can instead run `sqlite3 mamaearth.db < sql/schema.sql`, then `sqlite3 mamaearth.db < sql/seed_data.sql`, then `sqlite3 mamaearth.db < sql/reports.sql`. `schema.sql` drops and recreates tables, so running it resets the SQL database. The seed script inserts the unchanged CSV contents and represents blank `discount_pct` and `rating` values as SQL `NULL`. `reports.sql` contains the nine requested report tasks, including independent zero-order customer checks, ranking tie-break explanation, and loyalty-tier update. Expected row counts are 45 customers, 16 products, and 180 raw orders. Run this layer on the raw data; do not apply pandas cleaning to the SQL tables.

### 2. Python/Pandas cleaning, EDA, and charts

Run these commands from the repository root:

```bash
python analysis/clean_and_eda.py
python analysis/visualize.py
```

The first script independently loads the three raw CSVs, prints the required intermediate results, standardizes payment methods, detects and removes five duplicate orders, imputes missing values, reconciles revenue, flags quantity outliers without deleting them, computes return-rate segments/correlations/monthly revenue, and writes `narrator/findings.json` at the end from computed values. It also writes `analysis/eda_results.json`, a machine-readable handoff to the visualization script. The second script regenerates `visualizations/return_rate_by_payment.png` and `visualizations/monthly_revenue_trend.png` from that output. The monthly trend chart uses outlier-corrected revenue.

### 3. GenAI narrative

The narrator consumes the generated `narrator/findings.json` file:

```bash
python narrator/generate_narrative.py
```

**Offline/keyless mode (default):** If neither `GEMINI_API_KEY` nor `GOOGLE_API_KEY` is set, the script uses a deterministic f-string template. No network access, API key, or API spend is required. It runs the numeric accuracy checklist and saves the output to `narrator/sample_output.txt`.

**Optional Gemini free-tier mode:** Create a key in Google AI Studio and set it as an environment variable. Do not commit the key to GitHub.

Windows PowerShell:

```powershell
$env:GEMINI_API_KEY = "YOUR_KEY_HERE"
python narrator/generate_narrative.py
```

macOS/Linux:

```bash
export GEMINI_API_KEY="YOUR_KEY_HERE"
python narrator/generate_narrative.py
```

The script sets temperature to `0.0`, an explicit output-token limit, and a 30-second request timeout. API failures fall back to the offline narrative. The saved sample is checked for the required figures so grading does not rely on a live API call.

## Data-flow contract

1. SQL reads the raw CSV values inserted by `sql/seed_data.sql` and reports raw-data metrics.
2. The independent pandas pipeline reads the same raw CSVs, cleans the analysis frame, and computes its own verified metrics.
3. At the end of `clean_and_eda.py`, those computed metrics are exported to `narrator/findings.json`; the narrator interpolates the supplied dictionary rather than hardcoding business numbers.
4. The visualization layer reads `analysis/eda_results.json`, which is generated by the same pandas run. No chart or narrative needs manually edited intermediate values.

## Expected key checks

- SQL raw counts: 45 customers, 16 products, 180 orders.
- Raw SQL revenue: ₹99,860.20; cleaned pandas revenue: ₹97,358.30.
- Five duplicate rows removed; duplicate-driven reconciliation delta: ₹2,501.90.
- Payment-method return rates: COD 44.4%, CARD 14.7%, UPI 18.9%.
- Highest-risk segment: COD + Tier-2 at 54.5%.
- Outlier-corrected peak: March 2026 at ₹20,318.90.

## Notes

The data is a synthetic capstone dataset supplied with the assignment, not an assertion about Mamaearth's actual business. Correlations and observed return-rate differences are descriptive and do not establish causation. Generated PNGs and JSON outputs can be reproduced by running the scripts above.
