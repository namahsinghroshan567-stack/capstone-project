"""Create the two required reproducible charts from computed EDA output."""
from pathlib import Path
import json
import matplotlib.pyplot as plt

ROOT = Path(__file__).resolve().parents[1]
RESULTS = json.loads((ROOT / "analysis" / "eda_results.json").read_text(encoding="utf-8"))
OUT = ROOT / "visualizations"
OUT.mkdir(exist_ok=True)

rates = RESULTS["return_rate_by_payment"]
items = sorted(rates.items(), key=lambda item: item[1], reverse=True)
labels = [item[0] for item in items]
values = [item[1] for item in items]
fig, ax = plt.subplots(figsize=(8, 5))
bars = ax.bar(labels, values)
ax.set_ylabel("Return rate (%)")
ax.set_xlabel("Payment method")
ax.set_title(f"COD Returns at {rates['COD']:.1f}% — {rates['COD']/rates['CARD']:.1f}x Card")
ax.set_ylim(0, max(values) * 1.18)
for bar, value in zip(bars, values):
    ax.text(bar.get_x() + bar.get_width()/2, bar.get_height() + 0.8, f"{value:.1f}%", ha="center", va="bottom")
fig.tight_layout()
fig.savefig(OUT / "return_rate_by_payment.png", dpi=160, bbox_inches="tight")
plt.close(fig)

monthly = RESULTS["monthly_revenue_excluding_outliers"]
months = list(monthly.keys())
revenues = list(monthly.values())
peak_month = months[max(range(len(revenues)), key=lambda i: revenues[i])]
fig, ax = plt.subplots(figsize=(9, 5))
ax.plot(months, revenues, marker="o")
ax.set_xlabel("Month")
ax.set_ylabel("Revenue (INR)")
ax.set_title(f"Outlier-Corrected Monthly Revenue — Peak: {peak_month}")
ax.tick_params(axis="x", rotation=35)
fig.tight_layout()
fig.savefig(OUT / "monthly_revenue_trend.png", dpi=160, bbox_inches="tight")
plt.close(fig)
print(f"Saved {OUT / 'return_rate_by_payment.png'}")
print(f"Saved {OUT / 'monthly_revenue_trend.png'}")
